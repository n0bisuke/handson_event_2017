﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageSearch.Services
{
    public class CognitiveServicesKeys
    {
		//Setup a Bing Search API key from: http://www.microsoft.com/cognitive-services
		public const string BingSearch = "ef96c46d582f49aa8f0bb3c610573ce0";

	} 
}
