﻿
namespace MyWeather.UWP
{
    public sealed partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            LoadApplication(new MyWeather.App());
        }
    }
}
